package com.example.finalB1.finalB1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalB1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
