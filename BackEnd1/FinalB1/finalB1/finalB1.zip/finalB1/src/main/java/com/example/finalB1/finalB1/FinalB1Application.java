package com.example.finalB1.finalB1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalB1Application {

	public static void main(String[] args) {
		SpringApplication.run(FinalB1Application.class, args);
	}

}
