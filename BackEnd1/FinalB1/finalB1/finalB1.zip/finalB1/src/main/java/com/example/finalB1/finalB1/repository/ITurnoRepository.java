package com.example.finalB1.finalB1.repository;

import com.example.finalB1.finalB1.entity.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ITurnoRepository extends JpaRepository<Turno,Long> {
}
