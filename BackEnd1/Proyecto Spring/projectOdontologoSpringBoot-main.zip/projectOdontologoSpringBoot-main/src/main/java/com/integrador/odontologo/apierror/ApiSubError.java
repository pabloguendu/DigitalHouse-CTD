package com.integrador.odontologo.apierror;

public abstract class ApiSubError {
}
