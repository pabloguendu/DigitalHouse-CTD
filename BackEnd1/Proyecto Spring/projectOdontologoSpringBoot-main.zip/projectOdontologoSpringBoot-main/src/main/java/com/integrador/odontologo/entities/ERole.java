package com.integrador.odontologo.entities;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_INVITADO
}
