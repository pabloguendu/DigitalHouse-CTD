package com.dh.peliculas.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeliculasApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(PeliculasApiApplication.class, args);
    }

}
